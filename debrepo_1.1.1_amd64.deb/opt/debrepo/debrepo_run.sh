#!/bin/bash
cd /opt/debrepo/
source ./venv/bin/activate
python main.py
