import ini
from dataclasses import dataclass
from typing import Optional, TypedDict
from pydpkg import Dpkg
import pathlib
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi import HTTPException
import uvicorn
from distutils.version import StrictVersion


app = FastAPI()
config = ini.parse(open('config.ini').read())


@dataclass
class PackageData:
    package: str
    version: Optional[str] = ""
    architecture: Optional[str] = ""
    filepath: Optional[str] = ""
    filename: Optional[str] = ""


    @property
    def architecture_lower(self) -> str:
        return self.architecture.lower()

    @property
    def version(self):
        return self._version

    @version.setter
    def version(self, value):
        tmp = value
        if value.count(".") == 0:
            value = value + ".0.0"
        elif value.count(".") == 1:
            value = value + ".0"
        elif value.count(".") > 2:
            split_values = value.split(".")
            value = split_values[0] + "." + split_values[1] + "." + split_values[2]
        self._version = value



def filter_packages(all_packages, version, architecture):
    filtered_packages = [
        deb_package
        for deb_package in all_packages
        if deb_package.version.startswith(version) and deb_package.architecture_lower.startswith(architecture.lower())
    ]
    filtered_packages.sort(key=lambda k: StrictVersion(k.version), reverse=True)
    return filtered_packages


def scan_deb(os_folder, package_name, version, architecture):
    path = pathlib.Path(config['common']['path'] + "/" + os_folder)
    all_packages = []

    for deb_file in list(path.rglob("*.deb")):
        dp = Dpkg(deb_file)
        package_file = PackageData(
            package=dp.package,
            version=dp.version,
            architecture=dp.architecture,
            filepath=dp.filename,
            filename=deb_file.name
        )
        if package_file.package == package_name:
            all_packages.append(package_file)

    if not all_packages:
        return None, None

    filter_result = filter_packages(all_packages, version, architecture)

    if not filter_result:
        return None, None

    return filter_result[0].filepath, filter_result[0].filename


@app.get("/{os_folder}/")
async def find_deb(
    os_folder: str,
    pckg: str,
    ver: Optional[str] = "",
    arch: Optional[str] = "",
):
    dep_filepath,  dep_filename = scan_deb(os_folder, pckg, ver, arch)
    if dep_filename is None:
        raise HTTPException(status_code=404, detail="File not found")

    return FileResponse(dep_filepath, filename=dep_filename)


if __name__ == "__main__":
    uvicorn.run(app, host=config['server']['host'], port=config['server']['port'])
