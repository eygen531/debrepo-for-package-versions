#!/bin/bash
source /opt/debrepo/venv/bin/activate
pip install -r /opt/debrepo/requirements.txt
